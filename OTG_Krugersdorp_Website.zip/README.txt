OTG WEBSITE — PUBLISHING GUIDE

1. Open index.html to preview the website.
2. Replace the # links for Instagram, YouTube and TikTok with OTG's real profile URLs.
3. Add your official photos/logo and streaming links when ready.
4. Upload the folder to a web-hosting service.
5. After it has a public web address, submit the site in Google Search Console so Google can discover/index it.

Important: the website content uses the OTG/member information supplied in the conversation. Public claims about awards, achievements or other facts should be added only when verified.
